import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Instrucciones here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Instrucciones extends Actor
{
    public Instrucciones(String texto)
  {
       GreenfootImage instrucciones = new GreenfootImage(texto.length()*50,200);
       instrucciones.setColor(Color.RED);
       instrucciones.drawString(texto,20,40);
       setImage(instrucciones);
    }
    /**
     * Act - do whatever the Instrucciones wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        click();
    }    
     private void click()
    {
      if(Greenfoot.mouseClicked(this))  
      {
          Greenfoot.playSound("ComenzarJuego.wav");
          Greenfoot.setWorld(new Jugabilidad());
        }
    }
}
