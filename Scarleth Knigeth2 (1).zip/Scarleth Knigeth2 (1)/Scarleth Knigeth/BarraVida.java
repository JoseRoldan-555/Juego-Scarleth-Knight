import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color.*;
/**
 * Write a description of class BarraVida here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BarraVida extends Actor
{
    /**
     * Act - do whatever the BarraVida wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    int vidas=5;
    int anchoBarra =150;
    int altoBarra = 20;
    int imprimir = (int)anchoBarra/vidas;
    
    public BarraVida()
    {
       update();
    }  
    public void act() 
    {
        // Add your action code here.
        update();
    }  
    public void update()
     {
       setImage(new GreenfootImage(anchoBarra+2,altoBarra+2));
       GreenfootImage imagen = getImage();
       imagen.setColor(Color.WHITE);
       imagen.drawRect(0,0,anchoBarra+1,altoBarra+1);
       imagen.setColor(Color.BLUE);
       imagen.fillRect(1,1,vidas*imprimir,altoBarra);
    }
    public void perderVida()
    {
        vidas--;
    }  
}
