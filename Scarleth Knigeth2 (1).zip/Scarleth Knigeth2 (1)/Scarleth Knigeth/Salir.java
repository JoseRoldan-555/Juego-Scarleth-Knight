import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Salir here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Salir extends Actor
{
    public Salir(String texto)
    {
        GreenfootImage salir = new GreenfootImage(texto.length()*50,200);
       salir.setColor(Color.RED);
       salir.drawString(texto,20,40);
       setImage(salir); 
    }
    /**
     * Act - do whatever the Salir wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        clickSalir();
    }    
     private void clickSalir()
    {
      if(Greenfoot.mouseClicked(this))  
      {
          Greenfoot.stop();
        }
    }
}
