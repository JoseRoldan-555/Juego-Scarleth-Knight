import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Regresar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Regresar extends Actor
{
    /**
     * Act - do whatever the Regresar wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Regresar(String texto)
  {
       GreenfootImage jugar = new GreenfootImage(texto.length()*50,200);
       jugar.setColor(Color.BLUE);
       jugar.drawString(texto,20,40);
       setImage(jugar);
      }  
    public void act() 
    {
        // Add your action code here.
       clickRegresar();
    }    
    private void clickRegresar()
    {
      if(Greenfoot.mouseClicked(this))  
      {
          Greenfoot.playSound("ComenzarJuego.wav");
          Greenfoot.setWorld(new Menu());
        }
    }
}
