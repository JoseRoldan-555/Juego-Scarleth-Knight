import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.io.File;
/**
 * Write a description of class Arca here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Arca extends Actor
{
    public static final int derechaDisparo=3;
    public static final int izquierdaDisparo=2;
    int direccion=2;
    boolean disparo = false;
    boolean ataqueEnemigo = false;
    private GreenfootImage[] animate = new GreenfootImage[10];
    private int ind;
    private GreenfootImage[] animate2 = new GreenfootImage[8];
    private int ind2;
    private GreenfootImage[] atacar = new GreenfootImage[5];
    int ind3=0;
    private int poder=0;
    int cont;
    int vSpeed=0;
    int aceleracion=0;
    boolean salto=true;
    boolean derecha=true;
    public Arca()
    {
        int i=0;
        while(i<10){
            animate[i] = new GreenfootImage("arcaWalk"+(i+1)+".png");
            i++;
        }
        ind=0;
        int e=0;
        while(e<8){
            animate2[e] = new GreenfootImage("arcaWalkR"+(e+1)+".png");
            e++;
        }
        int s=0;
        while(s<5){
            atacar[s] = new GreenfootImage("ataque"+(s+1)+".png");
            s++;
        }
        ind2=0;
        setImage(animate[0]);
        cont=0;

    }

    /**
     * Act - do whatever the Arca wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
           
            move();
            atacar();
            caida();
            caer();
            saltar();
            vidas();
            //puntosDePoder();
            ataqueDistancia(direccion);
            elEnemigo2();
    } 
    private void move()
    {
        if(Greenfoot.isKeyDown("d")){
            move(5);
            derecha=true;
            if(ind==7)
                ind=0;
            else
                ind++;
            setImage(animate[ind]);
            setDireccion(derechaDisparo);
            direccion=2;
        }

        if(Greenfoot.isKeyDown("a")){
            move(-5);
            derecha=false;
            if(ind2==7)
                ind2=0;
            else
                ind2++;
            setImage(animate2[ind2]);
            setDireccion(izquierdaDisparo);
            direccion=3;
        }
    }

    private void atacar()
    {
        if(Greenfoot.isKeyDown("j"))
        {
            if(ind3==4)
                ind3=0;
            else
                ind3++;
            setImage(atacar[ind3]);
            if(isTouching(Enemigo2.class))
            {
                removeTouching(Enemigo2.class);
            }
        }
    }

    private void caida(){
        setLocation(getX(), getY() + vSpeed);
        vSpeed = vSpeed + aceleracion;
    }

    private void caer(){
        if(!isTouching(ground.class)){
            vSpeed++;
            salto=false;
        }
        else if(isTouching(ground.class)){
            setLocation(getX(), getY() -1);
            vSpeed=0;
            salto=true;
        }
    }

    private void saltar(){
        if(Greenfoot.isKeyDown("space")){
            if(salto == true)
                vSpeed=-25;
        }

    }

    private void asesinado()
    {
        if(isTouching(Enemigo2.class)) 
        {
            if(derecha){
                this.setLocation(getX()-85,getY());
                setImage(animate[8]);}
            else if(!derecha){
                this.setLocation(getX()+85,getY());
                setImage(animate[9]);
            }
            else if(!salto){
                vSpeed=-20;
            }
            vSpeed=-10;
        }
    }

    public void elEnemigo2()
    {
        Actor Enemigo2 = getOneIntersectingObject(Enemigo2.class);
        if(Enemigo2 != null)
        {
            World myWorld = getWorld();
            Despertar despertar = (Despertar)myWorld;
            BarraVida barraVida = despertar.getBarraVida();
            if(ataqueEnemigo==false)
            {
                barraVida.perderVida();
                ataqueEnemigo = true;
                asesinado();
                if(barraVida.vidas<=0)
                {
                    Greenfoot.stop();
                    getWorld().showText("GAME OVER",550,309);
                    myWorld.removeObject(this);
                }
            }
        }
        else{
            ataqueEnemigo = false;  
        }
    }

    private void vidas()
    {
        getWorld().showText("Arca ",45,20);
    } 

    private void puntosDePoder()
    {
        getWorld().showText("Poder :"+poder,52,60);
    }
    private void setDireccion(int direccion)
    {
       switch(direccion) 
       {
           case izquierdaDisparo:
           if(Greenfoot.isKeyDown("L"))
           {
              setLocation(getX()-10,getY()); 
            }
            else {
                setLocation(getX()-1,getY());
            }
            break;
            case derechaDisparo:
            if(Greenfoot.isKeyDown("L"))
            {
              setLocation(getX()+10,getY()); 
            }
            else{
                setLocation(getX()+1,getY());
            }
            break;
        }
    }
    private void ataqueDistancia(int dAtaque)
    {
        if(disparo && Greenfoot.isKeyDown("K"))
        {
            Energia ene = new Energia(dAtaque);
            getWorld().addObject(ene,getX(),getY());
            disparo = false;
        }
        if(!disparo && !Greenfoot.isKeyDown("K"))
        {
            disparo = true;
        }
    }
    
}
