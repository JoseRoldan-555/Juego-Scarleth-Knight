import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color.*;
/**
 * Write a description of class Mundo1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Mundo1 extends Actor
{
     public Mundo1(String texto)
    {
        GreenfootImage mundo1 = new GreenfootImage(texto.length()*60,100);
        mundo1.setColor(Color.WHITE);
        mundo1.drawString(texto,2,20);
        setImage(mundo1);
    }
    /**
     * Act - do whatever the Mundo1 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        clickSeleccion();
    }    
    private void clickSeleccion()
    {
      if(Greenfoot.mouseClicked(this))  
      {
           Greenfoot.setWorld(new Despertar());
           Greenfoot.playSound("Cancion3.mp3");
      }
    }
}
