import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color.*;
import java.awt.Font.*;
/**
 * Write a description of class BarraSubjefe here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BarraSubjefe extends Actor
{
    GreenfootImage imagen;
    int cont;
    String mensaje;
    int x,y;
    int height;
    int contenedor;
    
    public BarraSubjefe(int c,int x,int y,int height)
    {
       cont=c;
       contenedor=c;
       imagen = new GreenfootImage(250,150);
       imagen.setColor(new Color(200,200,0,255));
       this.x=x;
       this.y=y;
       this.height=height;
       dibuja();
       
    }  
    public void act() 
    {
        // Add your action code here.
       
    }  
    public void dibuja()
     {
       imagen.clear();
       imagen.setColor(new Color(200,200,0,255));
       imagen.drawRect(x,y,contenedor,height);
       imagen.fillRect(x,y,cont,height);
       imagen.setColor(new Color(255,255,255,255));
       imagen.drawString(String.valueOf(cont),25,19);
       setImage(imagen);
    }
    public void incrementar()
    {
       cont++;
       dibuja();
    }   
    public void decrementar()
    {
        cont--;
        dibuja();
    }
    public int obtenerValor()
    {
        return cont;
    }
}
