import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class BarraEntrenamientoJ here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BarraEntrenamientoJ extends Actor
{
    /**
     * Act - do whatever the BarraEntrenamientoJ wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    int vidas2J=20;
    int anchoBarra =240;
    int altoBarra = 20;
    int mostrar = (int)anchoBarra/vidas2J;
    
    public BarraEntrenamientoJ()
    {
       control();
    }  
    public void act() 
    {
        // Add your action code here.
        control();
    }  
    public void control()
     {
       setImage(new GreenfootImage(anchoBarra+2,altoBarra+2));
       GreenfootImage imagen = getImage();
       imagen.setColor(Color.WHITE);
       imagen.drawRect(0,0,anchoBarra+1,altoBarra+1);
       imagen.setColor(Color.GREEN);
       imagen.fillRect(1,1,vidas2J*mostrar,altoBarra);
    }
    public void perderVida2()
    {
        vidas2J--;
    }  
}
