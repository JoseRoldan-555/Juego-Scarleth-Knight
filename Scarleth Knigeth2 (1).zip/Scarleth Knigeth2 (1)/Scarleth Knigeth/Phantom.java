import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.io.File;
/**
 * Write a description of class Phantom here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Phantom extends Actor
{

    /**
     * Act - do whatever the Phantom wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
       
 
            if(Greenfoot.getRandomNumber(100)<20)
            {
                turn(Greenfoot.getRandomNumber(60)-45);
                move(10);
            }
      
            if(isAtEdge())
            {
                turn(180);
            }
      
             // Add your action code here.
    }   
    
}
