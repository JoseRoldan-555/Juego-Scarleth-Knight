import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class BarraEntrenamientoA here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BarraEntrenamientoA extends Actor
{
    /**
     * Act - do whatever the BarraEntrenamientoA wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
   int vidas2=20;
    int anchoBarra =240;
    int altoBarra = 20;
    int mostrar = (int)anchoBarra/vidas2;
    
    public BarraEntrenamientoA()
    {
       manejo();
    }  
    public void act() 
    {
        // Add your action code here.
        manejo();
    }  
    public void manejo()
     {
       setImage(new GreenfootImage(anchoBarra+2,altoBarra+2));
       GreenfootImage imagen = getImage();
       imagen.setColor(Color.WHITE);
       imagen.drawRect(0,0,anchoBarra+1,altoBarra+1);
       imagen.setColor(Color.BLUE);
       imagen.fillRect(1,1,vidas2*mostrar,altoBarra);
    }
    public void perderVida2()
    {
        vidas2--;
    }  
}
