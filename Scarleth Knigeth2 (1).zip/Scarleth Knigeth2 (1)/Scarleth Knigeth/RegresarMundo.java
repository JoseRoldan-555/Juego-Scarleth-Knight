import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class RegresarMundo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class RegresarMundo extends Actor
{
    /**
     * Act - do whatever the RegresarMundo wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
  public RegresarMundo(String textoRegresar)
  {
       GreenfootImage regresarM = new GreenfootImage(textoRegresar.length()*50,200);
       regresarM.setColor(Color.WHITE);
       regresarM.drawString(textoRegresar,20,40);
       setImage(regresarM);
    }
    public void act() 
    {
        // Add your action code here.
        clickMundo();
    }
    private void clickMundo()
    {
      if(Greenfoot.mouseClicked(this))  
      {
          Greenfoot.setWorld(new MenuMundos());
        }
    }
}
