import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Historia here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Historia extends Actor
{
    /**
     * Act - do whatever the Historia wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Historia(String texto4)
  {
       GreenfootImage historia = new GreenfootImage(texto4.length()*50,200);
       historia.setColor(Color.RED);
       historia.drawString(texto4,20,40);
       setImage(historia);
    }
    public void act() 
    {
      clickHistoria();
    }
    private void clickHistoria()
    {
      if(Greenfoot.mouseClicked(this))  
      {
          Greenfoot.playSound("ComenzarJuego.wav");
          Greenfoot.setWorld(new Leyenda());
        }
    }
}
