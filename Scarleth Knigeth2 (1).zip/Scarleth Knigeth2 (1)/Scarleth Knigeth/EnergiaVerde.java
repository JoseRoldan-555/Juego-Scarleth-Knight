import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class EnergiaVerde here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class EnergiaVerde extends Actor
{
    int imagen=1;
    int velocidad=6;
    int posicion;
    GreenfootImage poderVerde;
    GreenfootImage poderVerde2;
    public EnergiaVerde(int direccion)
    {
        posicion = direccion;
        poderVerde = new GreenfootImage("Verde.png");
        poderVerde2 = new GreenfootImage("Verde2.png");
    }
    public void act() 
    {
        validacion();
    } 
    public void validacion()
    {
       switch(posicion){
           case 2:
           setLocation(getX()+velocidad,getY());
           setImage(poderVerde2);
           break;
           case 3:
           setLocation(getX()-velocidad,getY());
           setImage(poderVerde);
           break;
        }
        if((getX()>=getWorld().getWidth()-5) ||	(getX()<=5))
        {
            getWorld().removeObject(this);
        }
        
        else{
            if((getY()>=getWorld().getHeight()-5) ||(getY()<=5))
            {
                getWorld().removeObject(this);
            }
            else 
            if(imagen<16)
            imagen++;
        }
    }
}
