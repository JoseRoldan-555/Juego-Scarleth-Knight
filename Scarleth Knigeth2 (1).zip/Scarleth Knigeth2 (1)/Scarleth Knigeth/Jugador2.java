import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Jugador2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Jugador2 extends Actor
{
    public static final int derechaDisparo=3;
    public static final int izquierdaDisparo=2;
    int direccion=2;
    boolean disparo = false;
    boolean ataqueEnemigo = false;
    private GreenfootImage[] animate = new GreenfootImage[3];
    private int indice1;
    private GreenfootImage[] animate2 = new GreenfootImage[8];
    private int indice2;
    private GreenfootImage[] atacar = new GreenfootImage[1];
    int ind3=0;
    private int poder=0;
    int cont;
    int vSpeed=0;
    int aceleracion=0;
    boolean salto=true;
    boolean derecha=true;
    
    private GreenfootImage imageJugador2;
    private GreenfootImage imageJugador22;
    private GreenfootImage ataquej21;
    private GreenfootImage ataquej22;
    private GreenfootImage movimiento1;
    private GreenfootImage movimiento2;
    private GreenfootImage movimiento3;
    private GreenfootImage movimiento4;
    private GreenfootImage movimiento5;
    private GreenfootImage ataque;
    
    public Jugador2()
    {
        movimiento1 = new GreenfootImage("Maestro1.png");
        movimiento2 = new GreenfootImage("Maestro2.png");
        movimiento3 = new GreenfootImage("AtaqueVerde.png");//Izquierda
        movimiento5 = new GreenfootImage("VerdeMovimiento.png");
        indice1=0;
        indice2=0;
        setImage(movimiento5);
        cont=0;
        ataque = new GreenfootImage("Combate1.png");
    }

    public void act() 
    {
        move();
        caida();
        caer();
        saltar();
        atacar();
        ataqueDistancia(direccion);
         ArcaE();
    }
    private void move()
    {
        if(Greenfoot.isKeyDown("right")){
            move(5);
            derecha=true;
            if(getImage()==movimiento1)
            setImage(movimiento2);
            else
            setImage(movimiento1);
            setDireccion(derechaDisparo);
            direccion=2;
        }

        if(Greenfoot.isKeyDown("left")){
            move(-5);
            derecha=false;
            setImage(movimiento5);
            setDireccion(izquierdaDisparo);
            direccion=3;
        }
    }

    private void atacar()
    {
        if(Greenfoot.isKeyDown("1"))
        {
           setImage(movimiento3);
        }
    }

    private void caida(){
        setLocation(getX(), getY() + vSpeed);
        vSpeed = vSpeed + aceleracion;
    }

    private void caer(){
        if(!isTouching(ground.class)){
            vSpeed++;
            salto=false;
        }
        else if(isTouching(ground.class)){
            setLocation(getX(), getY() -1);
            vSpeed=0;
            salto=true;
        }
    }

    private void saltar(){
        if(Greenfoot.isKeyDown("2")){
            if(salto == true)
                vSpeed=-25;
        }
    
    }
    public void ArcaE()
    {
        Actor arca = getOneIntersectingObject(ArcaEntrenamiento.class);
        Actor energiaAzul = getOneIntersectingObject(EnergiaEntrenamiento.class);
        if(arca != null || energiaAzul!=null)
        {
          World myWorld = getWorld();
          Entrenamiento entrenamiento2 = (Entrenamiento)myWorld;
          BarraEntrenamientoJ barraVida = entrenamiento2.getBarra2();
          if(Greenfoot.isKeyDown("J") || isTouching(EnergiaEntrenamiento.class))
          {
              barraVida.perderVida2();
              ataqueEnemigo = true;
              if(barraVida.vidas2J<=0)
              {
                  getWorld().showText("Ganador: Arca",550,309);
                  myWorld.removeObject(this);
                }
            }
        }
        else{
          ataqueEnemigo = false;  
        }
    }
    private void setDireccion(int direccion)
    {
       switch(direccion) 
       {
           case izquierdaDisparo:
           if(Greenfoot.isKeyDown("4"))
           {
              setLocation(getX()-10,getY()); 
            }
            else {
                setLocation(getX()-1,getY());
            }
            break;
            case derechaDisparo:
            if(Greenfoot.isKeyDown("4"))
            {
              setLocation(getX()+10,getY()); 
            }
            else{
                setLocation(getX()+1,getY());
            }
            break;
        }
    }
    private void ataqueDistancia(int dAtaque)
    {
        if(disparo && Greenfoot.isKeyDown("3"))
        {
            EnergiaVerde ene = new EnergiaVerde(dAtaque);
            getWorld().addObject(ene,getX(),getY());
            disparo = false;
        }
        if(!disparo && !Greenfoot.isKeyDown("3"))
        {
            disparo = true;
        }
    }
}
