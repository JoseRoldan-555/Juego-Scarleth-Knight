import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Mundo4 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Mundo4 extends Actor
{
    /**
     * Act - do whatever the Mundo4 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
     public Mundo4(String texto3)
    {
        GreenfootImage mundo4 = new GreenfootImage(texto3.length()*60,100);
        mundo4.setColor(Color.WHITE);
        mundo4.drawString(texto3,2,20);
        setImage(mundo4);
    }
    public void act() 
    {
        // Add your action code here.
        clickSeleccion4();
    } 
    private void clickSeleccion4()
    {
      if(Greenfoot.mouseClicked(this))  
      {
           Greenfoot.setWorld(new Oscuridad());
           Greenfoot.playSound("Cancion5.mp3");
      }
    }
}
