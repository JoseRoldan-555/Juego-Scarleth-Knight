import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Creditos here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Creditos extends Actor
{
    /**
     * Act - do whatever the Creditos wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
     public Creditos(String texto5)
  {
       GreenfootImage creditos = new GreenfootImage(texto5.length()*50,200);
       creditos.setColor(Color.RED);
       creditos.drawString(texto5,20,40);
       setImage(creditos);
    }
    public void act() 
    {
        clickCreditos();
    } 
    private void clickCreditos()
    {
      if(Greenfoot.mouseClicked(this))  
      {
          Greenfoot.playSound("ComenzarJuego.wav");
          Greenfoot.setWorld(new CreditosIntegrantes());
        }
    }
}
