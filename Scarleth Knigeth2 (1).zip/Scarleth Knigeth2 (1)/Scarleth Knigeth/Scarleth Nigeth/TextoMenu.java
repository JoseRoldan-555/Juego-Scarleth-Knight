import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.lang.String;
/**
 * Write a description of class TextoMenu here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TextoMenu extends Actor
{
    public TextoMenu(String texto)
    {
        GreenfootImage img = new GreenfootImage(texto.length()*60,100);
        img.setColor(Color.WHITE);
        img.drawString(texto,2,20);
        setImage(img);
    }
    /**
     * Act - do whatever the TextoMenu wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
