import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Sacrificio here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Sacrificio extends World
{

    /**
     * Constructor for objects of class Sacrificio.
     * 
     */
    public Sacrificio()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1100, 616, 1); 
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Arca arca = new Arca();
        addObject(arca,145,521);
    }
}
