import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.io.File;
/**
 * Write a description of class Arca here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Arca extends Actor
{
    private GreenfootImage imageArca1;
    private GreenfootImage imageArca2;
    
    private int vidas;
    private int poder=0;
    public Arca()
    {
       imageArca1 = new GreenfootImage("Arca.png.png"); 
       imageArca2 = new GreenfootImage("ArcaRespirando.png.png");
       setImage(imageArca1);
       vidas=5;
    }
    /**
     * Act - do whatever the Arca wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        
      if(Greenfoot.isKeyDown("Right"))
      {
          if(getX()<1000)
          move(5);
      }
      if(Greenfoot.isKeyDown("Left"))
      {
          if(getX()>100)
          move(-5);  
      }
      if(Greenfoot.isKeyDown("up"))
      {
          if(getY()>360)
          setLocation(getX(), getY()-1);  
      }
      if(Greenfoot.isKeyDown("Down"))
      {
         setLocation(getX(), getY()+1);
      }
      if(getImage()==imageArca1)
      setImage(imageArca2);
      else
      setImage(imageArca1);
      
      Actor Phantom;
    Phantom=getOneObjectAtOffset(0,0,Phantom.class);
    if(Phantom!=null)
    {
        World world;
        world = getWorld();
        Despertar despertar = (Despertar)world;
        Contador contador = despertar.getContador();
        matarFantasmas();
        contador.agregar();
    }
    asesinado();
    vidas();
    puntosDePoder();
    }    
    
   private void matarFantasmas()
   {
       if(isTouching(Phantom.class))
       {
       removeTouching(Phantom.class);
       Greenfoot.playSound("Ataque.wav");
       }
    }
   private void asesinado()
   {
      if(isTouching(Enemigo.class)) 
      {
         this.setLocation(272,448);
          vidas--;
         if(vidas==0)
         {
          Greenfoot.stop();
          getWorld().showText("GAME OVER",550,309);
          }
        }
    }
    private void vidas()
    {
        getWorld().showText("Arca :"+vidas,45,20);
    } 
    private void puntosDePoder()
    {
        getWorld().showText("Poder :"+poder,52,60);
    }    
}
