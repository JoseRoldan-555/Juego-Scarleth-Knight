import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Despertar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
//JOSE ARTURO TULIAN ROLDÁN, EMMANUEL TLATELPA TORRES, ANGEL GABRIEL VAZQUEZ PEREZ
public class Despertar extends World
{
    Contador contador = new Contador();
    /**
     * Constructor for objects of class Despertar.
     * 
     */
    public Despertar()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1100, 618, 1); 
        prepare();
    }
   
    public Contador getContador()
    {
       return contador;
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {

        Arca arca = new Arca();
        addObject(arca,272,448);
        Phantom phantom = new Phantom();
        addObject(phantom,753,435);
        Phantom phantom2 = new Phantom();
        addObject(phantom2,600,388);
        Phantom phantom3 = new Phantom();
        addObject(phantom3,655,546);
        Phantom phantom4 = new Phantom();
        addObject(phantom4,473,475);
        Phantom phantom5 = new Phantom();
        addObject(phantom5,593,472);
        Phantom phantom6 = new Phantom();
        addObject(phantom6,467,570);
        Phantom phantom7 = new Phantom();
        addObject(phantom7,812,416);
        Phantom phantom8 = new Phantom();
        addObject(phantom8,822,498);
        Phantom phantom9 = new Phantom();
        addObject(phantom9,947,531);
        Phantom phantom10 = new Phantom();
        addObject(phantom10,975,423);
        Phantom phantom11 = new Phantom();
        addObject(phantom11,1026,504);
        Phantom phantom12 = new Phantom();
        addObject(phantom12,900,406);
        Phantom phantom13 = new Phantom();
        addObject(phantom13,771,573);
        Phantom phantom14 = new Phantom();
        addObject(phantom14,673,436);
        Phantom phantom15 = new Phantom();
        addObject(phantom15,508,395);
        Phantom phantom16 = new Phantom();
        addObject(phantom16,576,555);
        Phantom phantom17 = new Phantom();
        addObject(phantom17,882,562);
        Phantom phantom18 = new Phantom();
        addObject(phantom18,1031,575);
        Phantom phantom19 = new Phantom();
        addObject(phantom19,1062,416);
        Phantom phantom20 = new Phantom();
        addObject(phantom20,1050,350);
        Phantom phantom21 = new Phantom();
        addObject(phantom21,907,482);

        addObject(contador,200,100);
        contador.setLocation(210,13);
        contador.setLocation(217,23);
        phantom5.setLocation(584,485);
        Enemigo enemigo = new Enemigo();
        addObject(enemigo,584,485);
        phantom14.setLocation(672,452);
        Enemigo enemigo2 = new Enemigo();
        addObject(enemigo2,672,452);
        phantom21.setLocation(910,498);
        Enemigo enemigo3 = new Enemigo();
        addObject(enemigo3,910,498);
        phantom12.setLocation(897,429);
        Enemigo enemigo4 = new Enemigo();
        addObject(enemigo4,897,429);
        removeObject(enemigo2);
    }
}
