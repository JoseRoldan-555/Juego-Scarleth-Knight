import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ElInicioDelFin here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
//los mundos de entrenamiento. oscuridad y sacrificios aun no tendran nada por el simplemotivo de que estamos investigando y haciendo mas diseños para que quede mejor por ahora solo contara el primer mundo llamado "despertar" 
public class Entrenamiento extends World
{

    /**
     * Constructor for objects of class ElInicioDelFin.
     * 
     */
    public Entrenamiento()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1100, 619, 1); 
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Arca arca = new Arca();
        addObject(arca,224,470);
    }
}
