import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MenuMundos here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MenuMundos extends World
{

    /**
     * Constructor for objects of class MenuMundos.
     * 
     */
    public MenuMundos()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1100, 618, 1); 
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Mundo1 mundo1 = new Mundo1("EL DESPERTAR");
        addObject(mundo1,550,182);
        Mundo2 mundo2 = new Mundo2("ENTRENAMIENTO");
        addObject(mundo2,900,182);
        Mundo3 mundo3 = new Mundo3("SACRIFICIO");
        addObject(mundo3,1250,182);
        Mundo4 mundo4 = new Mundo4("OSCURIDAD");
        addObject(mundo4,470,380);
        TextoMenu textoMenu = new TextoMenu("A CONTINUACION ESCOJA UN MUNDO");
        addObject(textoMenu,1100,100);
    }
}
