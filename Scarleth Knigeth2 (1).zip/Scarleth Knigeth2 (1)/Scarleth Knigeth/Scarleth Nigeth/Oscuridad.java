import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Oscuridad here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public class Oscuridad extends World
{

    /**
     * Constructor for objects of class Oscuridad.
     * 
     */
    public Oscuridad()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(935, 619, 1); 
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Arca arca = new Arca();
        addObject(arca,202,473);
    }
}
