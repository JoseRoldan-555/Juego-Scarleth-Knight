import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color.*;

/**
 * Write a description of class Jugar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Jugar extends Actor
{
  public Jugar(String texto)
  {
       GreenfootImage jugar = new GreenfootImage(texto.length()*50,200);
       jugar.setColor(Color.RED);
       jugar.drawString(texto,20,40);
       setImage(jugar);
    }
    /**
     * Act - do whatever the Jugar wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
     click();
    }   
    private void click()
    {
      if(Greenfoot.mouseClicked(this))  
      {
          Greenfoot.playSound("ComenzarJuego.wav");
          Greenfoot.setWorld(new MenuMundos());
        }
    }
}
