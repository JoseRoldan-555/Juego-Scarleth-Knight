import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Mundo2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Mundo2 extends Actor
{
    /**
     * Act - do whatever the Mundo2 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Mundo2(String texto2)
    {
        GreenfootImage mundo2 = new GreenfootImage(texto2.length()*60,100);
        mundo2.setColor(Color.WHITE);
        mundo2.drawString(texto2,2,20);
        setImage(mundo2);
    }
    public void act() 
    {
        // Add your action code here.
        clickSeleccion2();
    }   
    private void clickSeleccion2()
    {
      if(Greenfoot.mouseClicked(this))  
      {
           Greenfoot.setWorld(new Entrenamiento());
      }
    }
}
