import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Menu extends World
{
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public Menu()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1100, 618, 1); 
        
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void iniciarJuego()
    {
       
        
    }

    public void act()
    {
       
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Jugar jugar = new Jugar("COMENZAR EL JUEGO");
        addObject(jugar,1050,390);
        Salir salir = new Salir("SALIR DEL JUEGO");
        addObject(salir,1000,460);
        Instrucciones instrucciones = new Instrucciones("INSTRUCCIONES");
        addObject(instrucciones,950,530);
    }
}
