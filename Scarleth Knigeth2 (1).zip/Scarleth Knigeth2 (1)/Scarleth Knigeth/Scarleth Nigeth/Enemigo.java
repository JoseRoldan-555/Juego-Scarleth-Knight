import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Enemigo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Enemigo extends Actor
{
    /**
     * Act - do whatever the Enemigo wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        ataqueNinja();
    } 
    
    private void ataqueNinja()
    {
       move(5);
        
            if(Greenfoot.getRandomNumber(100)<20)
            {
                turn(Greenfoot.getRandomNumber(50)-45);
                move(15);
            }
            if(isAtEdge())
            {
                turn(180);
            }
    }  
    
}
