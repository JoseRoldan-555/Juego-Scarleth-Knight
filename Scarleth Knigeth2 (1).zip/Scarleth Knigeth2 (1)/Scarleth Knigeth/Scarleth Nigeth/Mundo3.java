import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Mundo3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Mundo3 extends Actor
{
    /**
     * Act - do whatever the Mundo3 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Mundo3(String texto3)
    {
        GreenfootImage mundo3 = new GreenfootImage(texto3.length()*60,100);
        mundo3.setColor(Color.WHITE);
        mundo3.drawString(texto3,2,20);
        setImage(mundo3);
    }
    public void act() 
    {
        // Add your action code here.
        clickSeleccion3();
    } 
    private void clickSeleccion3()
    {
      if(Greenfoot.mouseClicked(this))  
      {
           Greenfoot.setWorld(new Sacrificio());
      }
    }
}
