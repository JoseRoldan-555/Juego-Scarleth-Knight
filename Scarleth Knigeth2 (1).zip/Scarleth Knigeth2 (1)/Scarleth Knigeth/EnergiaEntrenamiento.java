import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class EnergiaEntrenamiento here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class EnergiaEntrenamiento extends Actor
{
    int imagen=1;
    int velocidad=6;
    int posicion;
    GreenfootImage poder;
    GreenfootImage poder2;
    public EnergiaEntrenamiento(int direccion)
    {
        posicion = direccion;
        poder = new GreenfootImage("energia2.png");
        poder2 = new GreenfootImage("energia3.png");
    }
    public void act() 
    {
        validacion();
    } 
    public void validacion()
    {
       switch(posicion){
           case 2:
           setLocation(getX()+velocidad,getY());
           setImage(poder2);
           break;
           case 3:
           setLocation(getX()-velocidad,getY());
           setImage(poder);
           break;
        }
        if((getX()>=getWorld().getWidth()-5) ||	(getX()<=5))
        {
            getWorld().removeObject(this);
        }
        
        else{
            if((getY()>=getWorld().getHeight()-5) ||(getY()<=5))
            {
                getWorld().removeObject(this);
            }
            else 
            if(imagen<16)
            imagen++;
        }
    }
}
