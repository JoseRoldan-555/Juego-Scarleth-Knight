import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class EnemigoFeroz here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class EnemigoFeroz extends Actor
{
    int cont;
    int vSpeed=0;
    int aceleracion=0;
    boolean salto=true;
    GreenfootImage movimiento1;
    GreenfootImage movimiento2;
    GreenfootImage movimiento3;
    GreenfootImage movimiento4;
    
    public EnemigoFeroz()
    {
      movimiento1 = new GreenfootImage("Soldado1.png"); 
      movimiento2 = new GreenfootImage("Soldado2.png"); 
      movimiento3 = new GreenfootImage("Soldado3.png"); 
      movimiento4 = new GreenfootImage("Soldado4.png"); 
    }
    public void act() 
    {
       move();
       caida();
       caer();
       cont++;
    } 
    private void move()
    {
        if(cont<30){
        move(3);
        if(getImage()==movimiento2)
        setImage(movimiento4);
        else
        setImage(movimiento2);
    }
    
        if(cont>30 && cont<60){
        move(-3);
        if(getImage()==movimiento1)
        setImage(movimiento3);
        else
        setImage(movimiento1);
    }
       else if(cont>60){
        cont=0;
        }
    }
    private void caer(){
        if(!isTouching(ground.class)){
        vSpeed++;
        salto=false;
        }
        else if(isTouching(ground.class)){
            setLocation(getX(), getY() -1);
        vSpeed=0;
        salto=true;
        }
        }
        private void caida(){
        setLocation(getX(), getY() + vSpeed);
        vSpeed = vSpeed + aceleracion;
        }
}
