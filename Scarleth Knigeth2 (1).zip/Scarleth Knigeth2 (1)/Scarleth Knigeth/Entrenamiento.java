import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ElInicioDelFin here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
//los mundos de entrenamiento. oscuridad y sacrificios aun no tendran nada por el simplemotivo de que estamos investigando y haciendo mas diseños para que quede mejor por ahora solo contara el primer mundo llamado "despertar" 
public class Entrenamiento extends World
{
     BarraEntrenamientoA barra = new BarraEntrenamientoA();
     BarraEntrenamientoJ barra2 = new BarraEntrenamientoJ();
    /**
     * Constructor for objects of class ElInicioDelFin.
     * 
     */
    public Entrenamiento()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1100, 619, 1); 
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        RegresarMundo mundo = new RegresarMundo("REGRESAR AL MENU MUNDOS");
        addObject(mundo,650,200);
        addObject(barra2,870,70);

        addObject(barra,250,70);

        groundEntrenamiento groundEntrenamiento = new groundEntrenamiento();
        addObject(groundEntrenamiento,550,556);

        ArcaEntrenamiento arcaEntrenamiento = new ArcaEntrenamiento();
        addObject(arcaEntrenamiento,196,464);

        removeObject(arcaEntrenamiento);
        ArcaEntrenamiento arcaEntrenamiento2 = new ArcaEntrenamiento();
        addObject(arcaEntrenamiento2,165,463);
        Jugador2 jugador2 = new Jugador2();
        addObject(jugador2,947,470);

        showText("Arca ",100,70);
        showText("Savaturh",700,70);

       
        
        plataforma1 plataforma1 = new plataforma1(290, 35);
        addObject(plataforma1,267,279);
       
        plataforma1 plataforma12 = new plataforma1(290, 35);
        addObject(plataforma12,779,279);
    }

    public BarraEntrenamientoA getBarra()
    {
        return barra;
    }
    public BarraEntrenamientoJ getBarra2()
    {
        return barra2;
    }
   
}
