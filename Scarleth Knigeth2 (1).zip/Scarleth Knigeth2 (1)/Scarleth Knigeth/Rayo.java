import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Rayo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Rayo extends Actor
{
    GreenfootImage rayo1;
    int cont=0;
    public Rayo()
    {
        rayo1 = new GreenfootImage("Rayo.png");
        setImage(rayo1);
    }
    public void act() 
    {
        moverse();
        cont++;
    } 
    private void moverse()
    {
        
        if(cont<100){
        setLocation(getX(),getY()+5);
        
    }
       
    }
}
