import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Jefe here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Jefe extends Actor
{
   private GreenfootImage jefe1;
   private GreenfootImage jefe2;
   private GreenfootImage jefe3;
   private GreenfootImage jefe4;
   private GreenfootImage jefe5;
   boolean ataqueEnemigo = false;
   int cont=0;
   public Jefe()
   {
       jefe1 = new GreenfootImage("Jefe1.png");
       jefe2 = new GreenfootImage("J1.png");
       jefe3 = new GreenfootImage("J2.png");
       jefe4 = new GreenfootImage("J3.png");
       jefe5 = new GreenfootImage("J4.png");
       setImage(jefe1);
    }
    public void act() 
    {
        nombre();
        move();
        elEnemigo2();
        cont++;
    } 
    
   private void move()
    {
        if(cont<100){
        setLocation(getX(),getY()+5);
        if(getImage()==jefe1)
        setImage(jefe2);
        if(getImage()==jefe2)
        setImage(jefe3);
        if(getImage()==jefe3)
        setImage(jefe4);
        if(getImage()==jefe4)
        setImage(jefe5);
        else 
        setImage(jefe1);
    }
    
        if(cont>101 && cont<200){
        setLocation(getX(),getY()-5);
        if(getImage()==jefe1)
        setImage(jefe2);
        if(getImage()==jefe2)
        setImage(jefe3);
        if(getImage()==jefe3)
        setImage(jefe4);
        if(getImage()==jefe4)
        setImage(jefe5);
        else 
        setImage(jefe1);
    }
       else if(cont>201){
        cont=0;
        }
    }
   
    
     public void elEnemigo2()
    {
        Actor energiaFinal = getOneIntersectingObject(EnergiaFinal.class);
        if(energiaFinal != null)
        {
            World myWorld = getWorld();
            Oscuridad oscuridad = (Oscuridad)myWorld;
            BarraJefe barraVida = oscuridad.getBarraJefe();
            if(ataqueEnemigo==false)
            {
                barraVida.perderVida();
                ataqueEnemigo = true;
                if(barraVida.vidas<=-1)
                {
                    Greenfoot.stop();
                    getWorld().showText("FELICIDADES LO LOGRASTE",466,309);
                    myWorld.removeObject(this);
                }
            }
        }
        else{
            ataqueEnemigo = false;  
        }
    }
    private void nombre()
    {
        getWorld().showText("Jefe",630,10);
    } 

}
