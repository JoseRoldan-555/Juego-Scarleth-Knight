import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Jugabilidad here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Jugabilidad extends World
{

    /**
     * Constructor for objects of class Jugabilidad.
     * 
     */
    public Jugabilidad()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1100, 618, 1); 
    }
    public void act()
    {
       showText("Como jugar Scarlet nigeth",200,40); 
       
       showText("1.-Primero que nada debe darle click en comenzar juego",300,90);
       
       showText("2.-Deberas escoger el primer mundo para conocer la historia de Arca",360,140);
       
       showText("3.-Ocupa las teclas arriba,abajo,derecha,izquierda para desplazarte",350,190);
       
       showText("4.-Mas adelante ocuparemos diferntes modos de ataque con las teclas J,I,L,K",395,240);
       
       showText("5.-Muevete con las teclas para acabar con todos los fantasmas",330,290);
       
       showText("6.-Cuidate de sus ataques de energia",210,340);
       
       showText("7.-Supera los niveles y enfrentate al jefe final",245,390);
       
       prepare();
    }
    private void prepare()
    {
    Regresar regresar = new Regresar("Regresar al menu");
    addObject(regresar,550,550);   
    } 
}
