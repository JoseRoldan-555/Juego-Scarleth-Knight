import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.io.File;
/**
 * Write a description of class Enemigo2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Enemigo2 extends Actor
{
    private GreenfootImage[] animate = new GreenfootImage[8];
    private int ind;
    private GreenfootImage[] animate2 = new GreenfootImage[8];
    private int ind2;
    private int vidas;
    private int poder=0;
    int cont;
    int vSpeed=0;
    int aceleracion=0;
    boolean salto=true;
    public Enemigo2()
    {
        int i=0;
        while(i<8){
        animate[i] = new GreenfootImage("enemigo"+(i+1)+".png");
        i++;
        }
        ind=0;
        int e=0;
        while(e<8){
        animate2[e] = new GreenfootImage("enemigoR"+(e+1)+".png");
        e++;
        }
        ind2=0;
        setImage(animate[0]);
        vidas=5;
        cont=0;

    }

    /**
     * Act - do whatever the Enemigo2 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        
        move();
        caida();
        caer();
        saltar();
        eliminar();
        cont++;
    } 
    private void move()
    {
        if(cont<120){
        move(3);
        if(ind==7)
        ind=0;
        else
        ind++;
        setImage(animate[ind]);
    }
    
        if(cont>121 && cont<240){
        move(-3);
        if(ind2==7)
        ind2=0;
        else
        ind2++;
        setImage(animate2[ind2]);
    }
       else if(cont>241){
        cont=0;
        }
    }
    private void caida(){
        setLocation(getX(), getY() + vSpeed);
        vSpeed = vSpeed + aceleracion;
        }
    private void caer(){
        if(!isTouching(ground.class)){
        vSpeed++;
        salto=false;
        }
        else if(isTouching(ground.class)){
            setLocation(getX(), getY() -1);
        vSpeed=0;
        salto=true;
        }
        }
        private void saltar(){
        if(Greenfoot.isKeyDown("o")){
            if(salto == true)
        vSpeed=-20;
        }
        }   
        private void eliminar()
        {
        Actor energia;
        energia=getOneObjectAtOffset(0,0,Energia.class);
        if(energia!=null)
        {
            if(isTouching(Energia.class))
            {
            World world;
            world = getWorld();
            Despertar despertar = (Despertar)world;
            Contador contador = despertar.getContador();
            contador.agregar();
            eliminar2();
        }
    }
        }
        private void eliminar2(){
           if(isTouching(Energia.class))
           {
              getWorld().removeObject(this); 
            }
        }
}
