import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Oscuridad here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public class Oscuridad extends World
{
    BarraFinal barra = new BarraFinal();
    BarraJefe jefe = new BarraJefe();
    public Oscuridad()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(935, 619, 1); 
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        RegresarMundo mundo = new RegresarMundo("REGRESAR AL MENU MUNDOS");
        addObject(mundo,650,150);
        addObject(barra,180,10);
        addObject(jefe,640,10);
        Arca arca = new Arca();
        addObject(arca,202,459);
        Jefe jefe = new Jefe();
        addObject(jefe,720,459);
        BarraVida barraVida = new BarraVida();
        addObject(barraVida,239,110);
        barraVida.setLocation(166,50);
        barraVida.perderVida();
        barraVida.perderVida();
        barraVida.setLocation(220,51);
        barraVida.perderVida();
        barraVida.perderVida();
        BarraVida barraVida2 = new BarraVida();
        addObject(barraVida2,752,44);
        barraVida.setLocation(194,23);
        barraVida2.setLocation(742,22);
        barraVida2.setLocation(728,18);
        barraVida2.setLocation(727,23);
        barraVida2.setLocation(733,31);
        barraVida2.setLocation(762,27);
        plataforma1 plataforma1 = new plataforma1(10, 200);
        addObject(plataforma1,244,207);
        plataforma1.setLocation(262,225);
        removeObject(plataforma1);

        addObject(plataforma1,281,213);
        plataforma1.setLocation(159,157);
        plataforma1 plataforma12 = new plataforma1(100, 50);
        addObject(plataforma12,314,303);
        plataforma12.setLocation(304,300);
        plataforma1 plataforma13 = new plataforma1(100, 50);
        addObject(plataforma13,502,119);
        plataforma1 plataforma14 = new plataforma1(100, 50);
        addObject(plataforma14,461,448);
        plataforma14.setLocation(573,445);
        plataforma1 plataforma15 = new plataforma1(100, 50);
        addObject(plataforma15,760,274);
        removeObject(plataforma1);
        plataforma1 plataforma16 = new plataforma1(100, 50);
        addObject(plataforma16,136,150);
        removeObject(barraVida2);
        groundDespertar groundDespertar = new groundDespertar();
        addObject(groundDespertar,511,560);
        removeObject(groundDespertar);
        groundEntrenamiento groundEntrenamiento = new groundEntrenamiento();
        addObject(groundEntrenamiento,492,530);
        removeObject(groundEntrenamiento);
        plataforma1 plataforma17 = new plataforma1(300, 1100);
        addObject(plataforma17,474,549);
        removeObject(plataforma17);

        removeObject(plataforma17);

        plataforma17.setLocation(512,571);
        plataforma17.setLocation(496,575);
        removeObject(plataforma17);

        plataforma17.setLocation(496,609);
        plataforma17.setLocation(488,607);
        removeObject(plataforma17);

        removeObject(plataforma17);

        plataforma17.setLocation(508,623);
        plataforma17.setLocation(494,601);
        plataforma17.setLocation(502,342);
        removeObject(plataforma17);

        plataforma17.setLocation(484,552);
        removeObject(plataforma17);

        plataforma1 plataforma18 = new plataforma1(950, 120);
        addObject(plataforma18,470,557);

        removeObject(jefe);

        EnemigoFeroz enemigoFeroz = new EnemigoFeroz();
        addObject(enemigoFeroz,269,238);

        EnemigoFeroz enemigoFeroz2 = new EnemigoFeroz();
        addObject(enemigoFeroz2,97,88);
        EnemigoFeroz enemigoFeroz3 = new EnemigoFeroz();
        addObject(enemigoFeroz3,533,383);

        EnemigoFeroz enemigoFeroz4 = new EnemigoFeroz();
        addObject(enemigoFeroz4,460,57);
        EnemigoFeroz enemigoFeroz5 = new EnemigoFeroz();
        addObject(enemigoFeroz5,652,460);
        EnemigoFeroz enemigoFeroz6 = new EnemigoFeroz();
        addObject(enemigoFeroz6,336,455);

        EnemigoFeroz enemigoFeroz7 = new EnemigoFeroz();
        addObject(enemigoFeroz7,722,211);
        removeObject(barraVida);
        removeObject(arca);
        ArcaFinal arcaFinal = new ArcaFinal();
        addObject(arcaFinal,115,470);

        Jefe jefe2 = new Jefe();
        addObject(jefe2,881,35);
    }

    public BarraFinal getBarra()
    {
        return barra;
    }
     public BarraJefe getBarraJefe()
    {
        return jefe;
    }
}
