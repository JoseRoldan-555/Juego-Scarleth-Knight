import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Despertar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
//JOSE ARTURO TULIAN ROLDÁN, EMMANUEL TLATELPA TORRES, ANGEL GABRIEL VAZQUEZ PEREZ
public class Despertar extends World
{
    Contador contador = new Contador();
    BarraVida vida = new BarraVida();
    /**
     * Constructor for objects of class Despertar.
     * 
     */
    public Despertar()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(3100, 618, 1); 
        prepare();
    }
   
    public Contador getContador()
    {
       return contador;
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        RegresarMundo mundo = new RegresarMundo("REGRESAR AL MENU MUNDOS");
        addObject(mundo,650,200);
        Arca arca = new Arca();
        addObject(arca,272,448);
        addObject(vida,150,20);
        addObject(contador,500,100);
        contador.setLocation(210,13);
        contador.setLocation(217,23);

        groundDespertar groundDespertar = new groundDespertar();
        addObject(groundDespertar,1550,555);
        Enemigo2 enemigo2 = new Enemigo2();
        addObject(enemigo2,707,424);
        enemigo2.setLocation(764,470);
        contador.setLocation(313,16);

        contador.setLocation(304,24);
        plataforma1 plataforma1 = new plataforma1(500, 50);
        addObject(plataforma1,539,354);
        plataforma1.setLocation(630,363);

        Enemigo2 enemigo22 = new Enemigo2();
        addObject(enemigo22,415,297);

        plataforma1 plataforma12 = new plataforma1(450, 50);
        addObject(plataforma12,1168,142);
        Enemigo2 enemigo23 = new Enemigo2();
        addObject(enemigo23,973,87);
        plataforma1 plataforma13 = new plataforma1(450, 50);
        addObject(plataforma13,1392,362);
        Enemigo2 enemigo24 = new Enemigo2();
        addObject(enemigo24,1192,310);
        Enemigo2 enemigo25 = new Enemigo2();
        addObject(enemigo25,1348,471);
        plataforma1 plataforma14 = new plataforma1(450, 50);
        addObject(plataforma14,1903,166);
        Enemigo2 enemigo26 = new Enemigo2();
        addObject(enemigo26,1725,108);
        Enemigo2 enemigo27 = new Enemigo2();
        addObject(enemigo27,1889,474);
        plataforma1 plataforma15 = new plataforma1(450, 50);
        addObject(plataforma15,2475,367);
        Enemigo2 enemigo28 = new Enemigo2();
        addObject(enemigo28,2306,312);
        Enemigo2 enemigo29 = new Enemigo2();
        addObject(enemigo29,2722,478);
        
    }

    public BarraVida getBarraVida()
    {
        return vida;
    }
}
