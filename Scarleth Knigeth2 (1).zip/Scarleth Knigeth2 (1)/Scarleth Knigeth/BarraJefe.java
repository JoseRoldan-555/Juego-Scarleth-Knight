import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class BarraJefe here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BarraJefe extends Actor
{
   int vidas=30;
    int anchoBarra =600;
    int altoBarra = 20;
    int imprimir = (int)anchoBarra/vidas;
    
    public BarraJefe()
    {
       update();
    }  
    public void act() 
    {
        // Add your action code here.
        update();
    }  
    public void update()
     {
       setImage(new GreenfootImage(anchoBarra+2,altoBarra+2));
       GreenfootImage imagen = getImage();
       imagen.setColor(Color.WHITE);
       imagen.drawRect(0,0,anchoBarra+1,altoBarra+1);
       imagen.setColor(Color.YELLOW);
       imagen.fillRect(1,1,vidas*imprimir,altoBarra);
    }
    public void perderVida()
    {
        vidas--;
    }   
}
